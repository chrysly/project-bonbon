public class StateInput
{
}
